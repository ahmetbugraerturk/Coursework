#!/usr/bin/env sh
set -eu

LOGS_DIR="${LOGS_DIR:-logs/part4}"
TMAX="${TMAX:-60}"

failzx()
{
    echo "check failed: $1" >&2
    exit 1
}

latestzx=$(ls -td "$LOGS_DIR"/run_* 2>/dev/null | head -n 1 || true)
if [ -n "$latestzx" ]; then
    LOGS_DIR="$latestzx"
elif [ ! -f "$LOGS_DIR/freight.log" ]; then
    failzx "no log files or run directory found under $LOGS_DIR"
fi

[ -s "$LOGS_DIR/freight.log" ] || failzx "missing or empty freight.log"
[ -s "$LOGS_DIR/strait.log" ] || failzx "missing or empty strait.log"
[ -s "$LOGS_DIR/coffee.log" ] || failzx "missing or empty coffee.log"

for p in P1 P2 P3; do
    grep -q "producer=$p" "$LOGS_DIR/coffee.log" || failzx "coffee.log has no $p production"
done

for c in C1 C2 C3; do
    grep -q "consumer=$c" "$LOGS_DIR/coffee.log" || failzx "coffee.log has no $c demand"
done

for k in K1 K2 K3; do
    grep -q "strait=$k" "$LOGS_DIR/strait.log" || failzx "strait.log has no $k event"
done

max_timezx=$(awk '
{
    line = $0
    while (match(line, /time=[0-9]+/)) {
        value = substr(line, RSTART + 5, RLENGTH - 5) + 0
        if (value > max) {
            max = value
        }
        line = substr(line, RSTART + RLENGTH)
    }
}
END { print max + 0 }
' "$LOGS_DIR"/*.log)

[ "$max_timezx" -le "$TMAX" ] || failzx "max timestamp $max_timezx exceeds TMAX $TMAX"

echo "Part IV log check passed: $LOGS_DIR, max_time=$max_timezx"