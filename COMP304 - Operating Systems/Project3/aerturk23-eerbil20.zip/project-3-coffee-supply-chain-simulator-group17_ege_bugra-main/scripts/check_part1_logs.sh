#!/usr/bin/env sh
set -eu

LOGS_DIR="${LOGS_DIR:-logs/part1}"
TMAX="${TMAX:-60}"

fail()
{
    echo "check failed: $1" >&2
    exit 1
}

latest=$(ls -td "$LOGS_DIR"/run_* 2>/dev/null | head -n 1 || true)
if [ -n "$latest" ]; then
    LOGS_DIR="$latest"
elif [ ! -f "$LOGS_DIR/freight.log" ]; then
    fail "no log files or run directory found under $LOGS_DIR"
fi

[ -s "$LOGS_DIR/freight.log" ] || fail "missing or empty freight.log"
[ -s "$LOGS_DIR/strait.log" ] || fail "missing or empty strait.log"
[ -s "$LOGS_DIR/coffee.log" ] || fail "missing or empty coffee.log"

grep -q "from=P1 to=C2" "$LOGS_DIR/freight.log" || fail "freight.log has no P1 to C2 departure"
grep -q "strait=K1" "$LOGS_DIR/strait.log" || fail "strait.log has no K1 event"
grep -q "producer=P1" "$LOGS_DIR/coffee.log" || fail "coffee.log has no P1 production"
grep -q "consumer=C2" "$LOGS_DIR/coffee.log" || fail "coffee.log has no C2 demand"
grep -q "removed production=" "$LOGS_DIR/coffee.log" || fail "coffee.log has no matched removal"

if grep -E "from=(P2|P3|C1|C1|C3|K2|K3)|to=(P2|P3|C1|C3|K2|K3)|consumer=(C1|C3)|producer=(P2|P3)|strait=(K2|K3)" "$LOGS_DIR"/*.log >/dev/null; then
    fail "logs contain entities outside Part I"
fi

max_time=$(awk '
{
    line = $0
    while (match(line, /time=[0-9]+/)) {
        value = substr(line, RSTART + 5, RLENGTH - 5) + 0
        if (value > max) {
            max = value
        }
        line = substr(line, RSTART + RLENGTH)
    }
}
END { print max + 0 }
' "$LOGS_DIR"/*.log)

[ "$max_time" -le "$TMAX" ] || fail "max timestamp $max_time exceeds TMAX $TMAX"

echo "Part I log check passed: $LOGS_DIR, max_time=$max_time"
