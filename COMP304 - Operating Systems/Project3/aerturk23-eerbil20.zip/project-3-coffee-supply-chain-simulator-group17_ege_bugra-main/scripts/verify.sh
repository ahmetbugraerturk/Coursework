#!/usr/bin/env sh
set -eu

# Usage check
if [ $# -lt 1 ]; then
    echo "Usage: $0 <part_no> [tmax] [smax] [freights]"
    echo "Example: ./scripts/verify.sh 4 60 5 6"
    exit 1
fi

PART=$1
TMAX="${2:-60}"
SMAX="${3:-5}"
F_COUNT="${4:-6}"
LOGS_ROOT="logs/part$PART"

# Find latest run
latestzx=$(ls -td "$LOGS_ROOT"/run_* 2>/dev/null | head -n 1 || true)
if [ -n "$latestzx" ]; then
    LOGS_DIR="$latestzx"
else
    [ -d "$LOGS_ROOT" ] && LOGS_DIR="$LOGS_ROOT" || { echo "Directory not found"; exit 1; }
fi

echo "Starting Deep Verification: $LOGS_DIR"

# --- 1. RANGE CHECKS (Quality 1-3, Amount 1-Smax) ---
echo "Step 1: Checking Quality and Amount ranges..."
awk -v smax="$SMAX" '
/added production/ || /added demand/ {
    match($0, /q=[0-9]/); q = substr($0, RSTART+2, 1) + 0;
    match($0, /amount=[0-9]+/); a = substr($0, RSTART+7) + 0;
    if (q < 1 || q > 3) { print "ERROR: Invalid quality " q " at line: " $0; exit 1; }
    if (a < 1 || a > smax) { print "ERROR: Invalid amount " a " at line: " $0; exit 1; }
}
' "$LOGS_DIR/coffee.log"

# --- 2. MATCHING RULE CHECK (qp >= qc and sp >= sc) ---
echo "Step 2: Verifying Matching Criteria (qp >= qc, sp >= sc)..."
awk '
/added production=/ {
    match($0, /production=P[0-9]+/); id=substr($0, RSTART+11, RLENGTH-11);
    match($0, /q=[0-9]/); q=substr($0, RSTART+2, 1);
    match($0, /amount=[0-9]+/); a=substr($0, RSTART+7);
    pq[id]=q; pa[id]=a;
}
/added demand=/ {
    match($0, /demand=D[0-9]+/); id=substr($0, RSTART+7, RLENGTH-7);
    match($0, /q=[0-9]/); q=substr($0, RSTART+2, 1);
    match($0, /amount=[0-9]+/); a=substr($0, RSTART+7);
    dq[id]=q; da[id]=a;
}
/removed production=/ {
    match($0, /production=P[0-9]+/); pid=substr($0, RSTART+11, RLENGTH-11);
    match($0, /demand=D[0-9]+/); did=substr($0, RSTART+7, RLENGTH-7);
    if (pq[pid] < dq[did]) { print "ERROR: Quality mismatch! " pid "(" pq[pid] ") < " did "(" dq[did] ")"; exit 1; }
    if (pa[pid] < da[did]) { print "ERROR: Amount mismatch! " pid "(" pa[pid] ") < " did "(" da[did] ")"; exit 1; }
}
' "$LOGS_DIR/coffee.log"

# --- 3. STRAIT MUTUAL EXCLUSION & PRIORITY ---
echo "Step 3: Verifying Strait Mutual Exclusion and Priority Logic..."
awk '
# Pass 1: Get freight properties from freight.log
FILENAME == ARGV[1] && (/depart/ || /arrived/) {
    match($0, /freight=F[0-9]+/); fid=substr($0, RSTART+8, RLENGTH-8);
    match($0, /q=[0-9]/); q=substr($0, RSTART+2, 1) + 0;
    # FIXED: Added RLENGTH-7 and forced numeric coercion (+ 0)
    match($0, /amount=[0-9]+/); a=substr($0, RSTART+7, RLENGTH-7) + 0;
    fq[fid]=q; fa[fid]=a;
}
# Pass 2: Check straits
FILENAME == ARGV[2] && /entered/ {
    match($0, /strait=[^ ]+/); st=substr($0, RSTART+7, RLENGTH-7);
    match($0, /freight=[^ ]+/); fr=substr($0, RSTART+8, RLENGTH-8);
    
    if (busy[st]) { print "ERROR: Strait " st " is double occupied by " busy[st] " and " fr; exit 1; }
    busy[st] = fr;

    # Priority Check
    match($0, /waiters=[^ ]+/); w_str=substr($0, RSTART+8, RLENGTH-8);
    if (w_str != "none") {
        split(w_str, waiters, ",");
        for (i in waiters) {
            w_id = waiters[i];
            if (fq[w_id] > fq[fr]) {
                print "ERROR: Priority Violation! " w_id "(q=" fq[w_id] ") is waiting but " fr "(q=" fq[fr] ") entered " st;
                exit 1;
            }
            if (fq[w_id] == fq[fr] && fa[w_id] > fa[fr]) {
                print "ERROR: Priority Violation! " w_id "(a=" fa[w_id] ") is waiting but " fr "(a=" fa[fr] ") entered " st;
                exit 1;
            }
        }
    }
}
FILENAME == ARGV[2] && /exited/ {
    match($0, /strait=[^ ]+/); st=substr($0, RSTART+7, RLENGTH-7);
    busy[st] = "";
}
' "$LOGS_DIR/freight.log" "$LOGS_DIR/strait.log"

# --- 4. CONCURRENT FREIGHT COUNT (F Many Freights) ---
echo "Step 4: Checking Active Freight Count (F <= $F_COUNT)..."
awk -v fmax="$F_COUNT" '
/[[:space:]]depart[[:space:]]/ { active++; if (active > fmax) { print "ERROR: Active freights (" active ") exceeds F (" fmax ")"; exit 1; } }
/[[:space:]]arrived[[:space:]]/ { active--; }
' "$LOGS_DIR/freight.log"

# --- 5. REAL-TIME & TMAX CHECK ---
echo "Step 5: Verifying Simulation Time and Real-time flow..."
max_t=$(awk '{for(i=1;i<=NF;i++) if(match($i, /time=[0-9]+/)) {val=substr($i, RSTART+5, RLENGTH-5); if(val>max) max=val}} END {print max+0}' "$LOGS_DIR"/*.log)
if [ "$max_t" -gt "$TMAX" ]; then
    echo "ERROR: Simulation exceeded TMAX ($max_t > $TMAX)"; exit 1;
fi

# --- 6. LOG FORMAT CHECK ---
echo "Step 6: Checking Log Formats (Locations and IDs)..."
# Check freight.log for origin and destination based on new log format
awk '
/depart/ || /arrived/ {
    if (!match($0, /from=P[0-9]+/) || !match($0, /(to|at)=C[0-9]+/)) {
        print "ERROR: Missing origin (from) or destination (to/at) in freight.log at line: " $0;
        exit 1;
    }
}
' "$LOGS_DIR/freight.log"

# Check coffee.log for Freight ID during removal based on new log format
awk '
/removed production/ {
    if (!match($0, /freight=F[0-9]+/)) {
        print "ERROR: Freight ID missing during supply/demand removal in coffee.log at line: " $0;
        exit 1;
    }
}
' "$LOGS_DIR/coffee.log"

# --- 7. STRAIT TRAVEL TIME CHECK ---
echo "Step 7: Verifying Strait Travel Times..."
awk '
BEGIN {
    t_req["K1"] = 3;
    t_req["K2"] = 5;
    t_req["K3"] = 7;
}
/entered/ {
    match($0, /time=[0-9]+/); t_enter = substr($0, RSTART+5, RLENGTH-5);
    match($0, /strait=[^ ]+/); st=substr($0, RSTART+7, RLENGTH-7);
    match($0, /freight=[^ ]+/); fr=substr($0, RSTART+8, RLENGTH-8);
    enter_times[fr"-"st] = t_enter;
}
/exited/ {
    match($0, /time=[0-9]+/); t_exit = substr($0, RSTART+5, RLENGTH-5);
    match($0, /strait=[^ ]+/); st=substr($0, RSTART+7, RLENGTH-7);
    match($0, /freight=[^ ]+/); fr=substr($0, RSTART+8, RLENGTH-8);
    
    t_diff = t_exit - enter_times[fr"-"st];
    if (t_diff != t_req[st]) {
        print "ERROR: Invalid travel time in " st " for " fr ". Expected " t_req[st] " but took " t_diff;
        exit 1;
    }
}
' "$LOGS_DIR/strait.log"

# --- 8. SHORTEST ROUTE CHECK ---
echo "Step 8: Checking Shortest Route Logic (Min Travel Time)..."
awk '
BEGIN {
    min_time["P1-C1"] = 8;
    min_time["P1-C2"] = 6;  
    min_time["P1-C3"] = 14;
    min_time["P2-C1"] = 11;
    min_time["P2-C2"] = 2;  
    min_time["P2-C3"] = 8;
    min_time["P3-C1"] = 18;
    min_time["P3-C2"] = 10;  
    min_time["P3-C3"] = 8;
}
/depart/ {
    match($0, /time=[0-9]+/); t_depart = substr($0, RSTART+5, RLENGTH-5);
    match($0, /from=P[0-9]+/); pf = substr($0, RSTART+5, RLENGTH-5);
    match($0, /to=C[0-9]+/); cf = substr($0, RSTART+3, RLENGTH-3);
    match($0, /freight=F[0-9]+/); fr=substr($0, RSTART+8, RLENGTH-8);
    
    start_time[fr] = t_depart;
    route[fr] = pf "-" cf;
}
/arrived/ {
    match($0, /time=[0-9]+/); t_arrive = substr($0, RSTART+5, RLENGTH-5);
    match($0, /freight=F[0-9]+/); fr=substr($0, RSTART+8, RLENGTH-8);
    
    actual_time = t_arrive - start_time[fr];
    expected_min = min_time[route[fr]];
    
    if (expected_min != "" && actual_time < expected_min) {
        print "ERROR: " fr " arrived too fast! " route[fr] " took " actual_time "s, absolute minimum is " expected_min "s.";
        exit 1;
    }
}
' "$LOGS_DIR/freight.log"

# --- 9. RESOURCE COMPETITION CHECK ---
echo "Step 9: Verifying Resource Competition (No double consumption)..."
awk '
/removed production=/ {
    match($0, /production=P[0-9]+/); 
    if (RSTART > 0) {
        pid = substr($0, RSTART+11, RLENGTH-11);
        if (consumed_p[pid]) {
            print "ERROR: Race Condition detected! Production item " pid " was consumed more than once.";
            exit 1;
        }
        consumed_p[pid] = 1;
    }

    match($0, /demand=D[0-9]+/);
    if (RSTART > 0) {
        did = substr($0, RSTART+7, RLENGTH-7);
        if (consumed_d[did]) {
            print "ERROR: Race Condition detected! Demand item " did " was consumed more than once.";
            exit 1;
        }
        consumed_d[did] = 1;
    }
}
' "$LOGS_DIR/coffee.log"

echo "------------------------------------------------"
echo "All PDF Requirements Verified for Part $PART!"
echo "Final Simulation Time: $max_t"
echo "Log Directory: $LOGS_DIR"