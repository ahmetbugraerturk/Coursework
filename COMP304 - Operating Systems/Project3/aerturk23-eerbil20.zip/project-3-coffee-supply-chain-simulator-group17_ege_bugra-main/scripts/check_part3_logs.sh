#!/usr/bin/env sh
set -eu

LOGS_DIR="${LOGS_DIR:-logs/part3}"
TMAX="${TMAX:-60}"

failzx()
{
    echo "check failed: $1" >&2
    exit 1
}

latestzx=$(ls -td "$LOGS_DIR"/run_* 2>/dev/null | head -n 1 || true)
if [ -n "$latestzx" ]; then
    LOGS_DIR="$latestzx"
elif [ ! -f "$LOGS_DIR/freight.log" ]; then
    failzx "no log files or run directory found under $LOGS_DIR"
fi

[ -s "$LOGS_DIR/freight.log" ] || failzx "missing or empty freight.log"
[ -s "$LOGS_DIR/strait.log" ] || failzx "missing or empty strait.log"
[ -s "$LOGS_DIR/coffee.log" ] || failzx "missing or empty coffee.log"

grep -q "producer=P1" "$LOGS_DIR/coffee.log" || failzx "coffee.log has no P1 production"
grep -q "producer=P2" "$LOGS_DIR/coffee.log" || failzx "coffee.log has no P2 production"
grep -q "consumer=C1" "$LOGS_DIR/coffee.log" || failzx "coffee.log has no C1 demand"
grep -q "consumer=C2" "$LOGS_DIR/coffee.log" || failzx "coffee.log has no C2 demand"
grep -q "strait=K1" "$LOGS_DIR/strait.log" || failzx "strait.log has no K1 event"

if grep -E "from=(P3|C3|K2|K3)|to=(P3|C3|K2|K3)|consumer=C3|producer=P3|strait=(K2|K3)" "$LOGS_DIR"/*.log >/dev/null; then
    failzx "logs contain entities outside Part III (found Part IV elements)"
fi

max_timezx=$(awk '
{
    line = $0
    while (match(line, /time=[0-9]+/)) {
        value = substr(line, RSTART + 5, RLENGTH - 5) + 0
        if (value > max) {
            max = value
        }
        line = substr(line, RSTART + RLENGTH)
    }
}
END { print max + 0 }
' "$LOGS_DIR"/*.log)

[ "$max_timezx" -le "$TMAX" ] || failzx "max timestamp $max_timezx exceeds TMAX $TMAX"

echo "Part III log check passed: $LOGS_DIR, max_time=$max_timezx"