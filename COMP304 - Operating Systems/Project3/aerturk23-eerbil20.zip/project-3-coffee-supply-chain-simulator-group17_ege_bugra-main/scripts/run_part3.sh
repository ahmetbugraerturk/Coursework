#!/usr/bin/env sh
set -eu

TMAX="${TMAX:-60}"
SMAX="${SMAX:-5}"
FREIGHTS="${FREIGHTS:-6}"
SEED="${SEED:-304}"
TIME_SCALE="${TIME_SCALE:-1.0}"
LOGS_DIR="${LOGS_DIR:-logs}"
CONFIG="${CONFIG:-}"

make
if [ -n "$CONFIG" ]; then
    ./coffee_sim --config "$CONFIG" --part 3 --tmax "$TMAX" --smax "$SMAX" --freights "$FREIGHTS" --seed "$SEED" --time-scale "$TIME_SCALE" --logs "$LOGS_DIR"
else
    ./coffee_sim --part 3 --tmax "$TMAX" --smax "$SMAX" --freights "$FREIGHTS" --seed "$SEED" --time-scale "$TIME_SCALE" --logs "$LOGS_DIR"
fi
