#!/usr/bin/env sh
# Log-check helper prepared with AI assistance for Part II testing.
set -eu

LOGS_DIR="${LOGS_DIR:-logs/part2}"
TMAX="${TMAX:-60}"

fail()
{
    echo "check failed: $1" >&2
    exit 1
}

latest=$(ls -td "$LOGS_DIR"/run_* 2>/dev/null | head -n 1 || true)
if [ -n "$latest" ]; then
    LOGS_DIR="$latest"
elif [ ! -f "$LOGS_DIR/freight.log" ]; then
    fail "no log files or run directory found under $LOGS_DIR"
fi

[ -s "$LOGS_DIR/freight.log" ] || fail "missing or empty freight.log"
[ -s "$LOGS_DIR/strait.log" ] || fail "missing or empty strait.log"
[ -s "$LOGS_DIR/coffee.log" ] || fail "missing or empty coffee.log"

grep -q "from=P1 to=C2" "$LOGS_DIR/freight.log" || fail "freight.log has no P1 to C2 departure"
grep -q "consumer=C1" "$LOGS_DIR/coffee.log" || fail "coffee.log has no C1 demand"
grep -q "consumer=C2" "$LOGS_DIR/coffee.log" || fail "coffee.log has no C2 demand"
grep -q "strait=K1" "$LOGS_DIR/strait.log" || fail "strait.log has no K1 event"
grep -q "removed production=" "$LOGS_DIR/coffee.log" || fail "coffee.log has no matched removal"

if grep -E "from=(P2|P3|C3|K2|K3)|to=(P2|P3|C3|K2|K3)|consumer=C3|producer=(P2|P3)|strait=(K2|K3)" "$LOGS_DIR"/*.log >/dev/null; then
    fail "logs contain entities outside Part II"
fi

max_time=$(awk '
{
    line = $0
    while (match(line, /time=[0-9]+/)) {
        value = substr(line, RSTART + 5, RLENGTH - 5) + 0
        if (value > max) {
            max = value
        }
        line = substr(line, RSTART + RLENGTH)
    }
}
END { print max + 0 }
' "$LOGS_DIR"/*.log)

[ "$max_time" -le "$TMAX" ] || fail "max timestamp $max_time exceeds TMAX $TMAX"

echo "Part II log check passed: $LOGS_DIR, max_time=$max_time"
