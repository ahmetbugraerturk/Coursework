# Coffee Supply Chain Simulator

**Ege Yiğit Erbil** & **Ahmet Buğra Ertürk** Koç University, Sarıyer, Istanbul — COMP304 Operating Systems

**GitHub Repository:** <https://github.com/KocUniversity/project-3-coffee-supply-chain-simulator-group17_ege_bugra>

A multi-threaded C simulator for the COMP 304 Project 3 coffee logistics
network. The program models producers, consumers, freight vehicles, weighted
routes, and one-at-a-time strait crossings with POSIX threads.

The current implementation has built-in defaults for Part I and Part II, plus a
plain-text scenario-file loader for custom maps and parameters.

## Implemented Status

| Area | Status |
| --- | --- |
| Part I built-in map | Implemented |
| Part II built-in map | Implemented |
| Part III built-in map | Implemented |
| Part IV built-in map | Implemented |
| Scenario/config files | Implemented |
| Run helper scripts | Implemented |
| Log checker scripts | Implemented |
| Project requirement verification script | Implemented |

Built-in maps:

| Part | Map | Log directory |
| --- | --- | --- |
| I | `P1`, `K1`, `C2` with routes `P1-K1`, `K1-C2` | `logs/part1/...` |
| II | Part I plus consumer `C1` and routes `P1-C1`, `K1-C1` | `logs/part2/...` |
| III | Adding `P2` and competition for shared resources | `logs/part3/...` |
| IV | Full Figure 1 Map including `P3`, `C3`, `K2`, `K3` | `logs/part4/...` |

## Build

Use Linux or WSL with `gcc`, `make`, and pthread support.

Ubuntu/Debian setup:

```bash
sudo apt update
sudo apt install build-essential
```

Build:

```bash
make clean
make
```

The executable is:

```bash
./coffee_sim
```

## Quick Start

Run Part I:

```bash
./coffee_sim --part1
```

Run Part II:

```bash
./coffee_sim --part2
```

Run Part III:

```bash
./coffee_sim --part3
```

Run Part IV:

```bash
./coffee_sim --part4
```

The Makefile also has convenience targets:

```bash
make part1
make part2
make part3
make part4
```

Each run prints the generated log directory:

```text
logs=logs/part2/run_1778092200_123456_4321
```

Default values:

```text
Tmax = 60
Smax = 5
F    = 6 freight threads
seed = 304
time_scale = 1.0
```

A normal default run takes about 60 real seconds. For faster local checks:

```bash
./coffee_sim --part2 --tmax 10 --time-scale 0.05 --logs logs_smoke
```

## Helper Scripts

Run the default Part I scenario:

```bash
sh scripts/run_part1.sh
```

Run the default Part II scenario:

```bash
sh scripts/run_part2.sh
```

Run the default Part III scenario:

```bash
sh scripts/run_part3.sh
```

Run the default Part IV scenario:

```bash
sh scripts/run_part4.sh
```

The scripts accept environment overrides:

```bash
TMAX=18 TIME_SCALE=0.05 LOGS_DIR=logs_smoke_p1 sh scripts/run_part1.sh
TMAX=18 TIME_SCALE=0.05 LOGS_DIR=logs_smoke_p2 sh scripts/run_part2.sh
TMAX=18 TIME_SCALE=0.05 LOGS_DIR=logs_smoke_p3 sh scripts/run_part3.sh
TMAX=18 TIME_SCALE=0.05 LOGS_DIR=logs_smoke_p4 sh scripts/run_part4.sh
```

Check the latest Part I logs:

```bash
sh scripts/check_part1_logs.sh
```

Check the latest Part II logs:

```bash
sh scripts/check_part2_logs.sh
```

Check the latest Part III logs:

```bash
sh scripts/check_part3_logs.sh
```

Check the latest Part IV logs:

```bash
sh scripts/check_part4_logs.sh
```

Equivalent Makefile targets:

```bash
make check-part1
make check-part2
make check-part3
make check-part4
```

## Deep Logic Verification

A specialized verification script is provided to ensure simulation logs strictly adhere to all maritime logistics and synchronization requirements.

Usage:
```bash
./scripts/verify.sh <part_no> [tmax] [smax] [freights]
# for example:
./scripts/verify.sh 4 60 5 6
```
The script performs the following validation steps:

1. **Range Checks:** Validates that quality is within {1, 2, 3} and amounts are within [1, $S_{max}$].
2. **Matching Criteria:** Verifies for every delivery that $q_p \geq q_c$ and $s_p \geq s_c$.
3. **Strait Mutual Exclusion & Priority:** Confirms only one freight occupies a strait at a time and verifies the Quality > Amount priority logic.
4. **Active Freight Limit:** Ensures concurrent freights never exceed the system limit $F$.
5. **Real-time & $T_{max}$:** Validates all log timestamps are within the $T_{max}$ boundary.
6. **Log Format Integrity:** Checks for mandatory fields (origin, destination, IDs) in all log files.
7. **Strait Travel Times:** Confirms that straits $K_1$, $K_2$, $K_3$ enforce their specific travel durations ($t_k$).
8. **Shortest Route Logic:** Cross-references delivery times with Dijkstra-calculated minimum travel times for each $P−C$ pair.
9. **Resource Competition:** Detects race conditions by ensuring no supply or demand item is consumed more than once.

## Command-Line Options

| Option | Meaning |
| --- | --- |
| `--part N` | Select the part label and built-in map when no config graph is loaded |
| `--part1`, `--partI` | Alias for Part I |
| `--part2`, `--partII` | Alias for Part II |
| `--part3`, `--partIII` | Allowed only with `--config` |
| `--part4`, `--partIV` | Allowed only with `--config` |
| `--config FILE` | Load a scenario file before command-line overrides |
| `--tmax N` | Simulation length in simulated seconds |
| `--smax N` | Maximum generated coffee amount |
| `--freights N` | Number of active freight threads |
| `--seed N` | Random seed for reproducible runs |
| `--time-scale X` | Real seconds per simulated second |
| `--logs DIR` | Root directory for generated logs |

Config files are loaded first. Command-line options then override config values,
so this uses the Part II scenario but changes the freight count:

```bash
./coffee_sim --config configs/part2.scn --freights 12
```

## Scenario Files

Scenario files are plain text. They define simulation parameters and graph
topology without changing C code.

Available examples:

```text
configs/part1.scn
configs/part2.scn
configs/part3.scn
configs/part4.scn
configs/example_custom.scn
```

Supported directives:

```text
# comments are ignored
part 2
tmax 60
smax 5
freights 6
seed 304
time_scale 1.0
logs logs

clear_graph
active P1 K1 C1 C2
edge P1 K1 2
edge K1 C2 4
edge P1 C1 8
edge K1 C1 7

producer P1 0.90
consumer C1 0.50
consumer C2 0.90
strait K1 3
```

Entity directives:

```text
producer NAME PROBABILITY
consumer NAME PROBABILITY
strait NAME TRAVEL_TIME
```

Each `edge A B T` line creates an undirected route with travel time `T`.
Every active vertex must have exactly one role: producer, consumer, or strait.
Node names may contain letters, digits, `_`, and `-`, and must be shorter than
32 characters.

Current configurable graph limits:

```text
max vertices = 128
max straits  = 64
```

## Simulation Logic

Producer threads create coffee supply items over time. Consumer threads create
demand items. Each item has a quality and an amount.

A freight can match supply to demand when:

```text
supply_quality >= demand_quality
supply_amount  >= demand_amount
```

Matched supply and demand items are removed from the shared coffee lists. The
freight then chooses a shortest path through the weighted graph and travels edge
by edge until delivery.

Straits are bottlenecks. Each strait has its own mutex and condition variable,
and only one freight may pass at a time. Waiting freights are prioritized by
higher coffee quality, then larger amount, then arrival order.

The supply/demand lists use one shared mutex. Log events are placed into a
thread-safe queue and written by a separate logger thread, so worker threads do
not perform direct file writes.

## Output Logs

Every run creates a fresh directory:

```text
logs/partN/run_<timestamp>_<usec>_<pid>/
|-- freight.log
|-- strait.log
`-- coffee.log
```

| Log file | Contents |
| --- | --- |
| `freight.log` | Freight departure and arrival events, matched production/demand IDs, route endpoints, route text, quality, amount, and timing |
| `strait.log` | Strait enter/exit events, selected freight, timestamp, and current waiters |
| `coffee.log` | Supply/demand additions, matched removals, and queue snapshots |

Generated logs are not committed by default. Create them locally when testing or
when the submission instructions ask for sample output.

## Repository Layout

```text
.
|-- configs/
|   |-- example_custom.scn
|   |-- part1.scn
|   |-- part2.scn
|   |-- part3.scn
|   `-- part4.scn
|-- scripts/
|   |-- check_part1_logs.sh
|   |-- check_part2_logs.sh
|   |-- check_part3_logs.sh
|   |-- check_part4_logs.sh
|   |-- run_part1.sh
|   |-- run_part2.sh
|   |-- run_part3.sh
|   |-- run_part4.sh
|   `-- verify.sh
|-- src/
|   `-- coffee_sim.c
|-- Makefile
`-- README.md
```

## AI Assistance Disclosure

AI assistance was used to help draft this README because documentation writing
is repetitive and easy to postpone. The README was reviewed and adjusted to
match the current implementation. The implementation, testing, and final
submission remain the authors' responsibility, except verify.sh file that helps to check the requirements of the project.
