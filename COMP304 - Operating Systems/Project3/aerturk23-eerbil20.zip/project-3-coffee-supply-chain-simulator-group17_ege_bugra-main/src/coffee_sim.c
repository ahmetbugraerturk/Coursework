#define _POSIX_C_SOURCE 200809L

#include <ctype.h>
#include <errno.h>
#include <limits.h>
#include <pthread.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>

#define MAX_VERTICES 128
#define MAX_STRAITS 64
#define MAX_ITEMS 4096
#define MAX_WAITING 256
#define LOG_QUEUE_SIZE 4096
#define MAX_NAME 32
#define MAX_PATH MAX_VERTICES

typedef enum {
    KIND_UNKNOWN,
    KIND_PRODUCER,
    KIND_CONSUMER,
    KIND_STRAIT
} VertexKind;

typedef enum {
    LOG_FREIGHT,
    LOG_STRAIT,
    LOG_COFFEE
} LogType;

typedef struct {
    char name[MAX_NAME];
    VertexKind kind;
    int active;
    double probability;
    int strait_index;
} Vertex;

typedef struct {
    Vertex vertices[MAX_VERTICES];
    int vertex_count;
    int edge_time[MAX_VERTICES][MAX_VERTICES];
} Graph;

typedef struct {
    int id;
    int producer;
    int quality;
    int amount;
    int time;
} SupplyItem;

typedef struct {
    int id;
    int consumer;
    int quality;
    int amount;
    int time;
} DemandItem;

typedef struct {
    int freight_id;
    int quality;
    int amount;
    long ticket;
} StraitRequest;

typedef struct {
    int id;
    int vertex;
    int travel_time;
    int busy;
    int reserved_count;
    long next_ticket;
    StraitRequest *waiting[MAX_WAITING];
    int waiting_count;
    pthread_mutex_t mutex;
    pthread_cond_t cond;
} Strait;

typedef struct {
    LogType type;
    char *line;
} LogEvent;

typedef struct {
    LogEvent events[LOG_QUEUE_SIZE];
    int head;
    int tail;
    int count;
    int closed;
    pthread_mutex_t mutex;
    pthread_cond_t not_empty;
    pthread_cond_t not_full;
} LogQueue;

typedef struct {
    int part;
    int tmax;
    int smax;
    int freight_count;
    unsigned int seed;
    double time_scale;
    char logs_root[256];
    char config_path[256];
    char run_dir[512];
    int graph_loaded;
    Graph graph;
    int strait_travel_time[MAX_VERTICES];
} Config;

typedef struct {
    Config config;
    Graph graph;
    Strait straits[MAX_STRAITS];
    int strait_count;

    SupplyItem supplies[MAX_ITEMS];
    int supply_count;
    DemandItem demands[MAX_ITEMS];
    int demand_count;
    int next_supply_id;
    int next_demand_id;
    int next_freight_id;

    pthread_mutex_t list_mutex;
    LogQueue log_queue;
 
    int active_freights;
    pthread_mutex_t active_mutex;
    pthread_cond_t active_cond;

    struct timespec start_time;
} Sim;

typedef struct {
    Sim *sim;
    int vertex;
    double probability;
    unsigned int seed;
} EntityArg;

typedef struct {
    Sim *sim;
    int slot;
    unsigned int seed;
} FreightArg;

typedef struct {
    Sim *sim;
    char part_dir[512];
} LoggerArg;

typedef struct {
    int freight_id;
    int producer;
    int consumer;
    int production_id;
    int demand_id;
    int quality;
    int amount;
    int departure_time;
} Match;

static int sim_time(Sim *sim);
static int shortest_path(Graph *graph, int start, int goal, int *path, int *path_count);

/* Empty the map. I use this before loading defaults or a config file. */
static void graph_clear(Graph *graph)
{
    int i;
    int j;
    memset(graph, 0, sizeof(*graph));
    for (i = 0; i < MAX_VERTICES; i++) {
        graph->vertices[i].strait_index = -1;
        for (j = 0; j < MAX_VERTICES; j++) {
            graph->edge_time[i][j] = -1;
        }
    }
}

/* Same idea as graph_clear, but also clears strait times. */
static void config_clear_graph(Config *config)
{
    int i;
    graph_clear(&config->graph);
    for (i = 0; i < MAX_VERTICES; i++) {
        config->strait_travel_time[i] = 0;
    }
    config->graph_loaded = 1;
}

/* Keep names simple so config parsing and logs do not get weird with spaces. */
static int valid_name(const char *name)
{
    size_t len = strlen(name);
    size_t i;
    if (len == 0 || len >= MAX_NAME) {
        return 0;
    }
    for (i = 0; i < len; i++) {
        unsigned char ch = (unsigned char)name[i];
        if (!isalnum(ch) && ch != '_' && ch != '-') {
            return 0;
        }
    }
    return 1;
}

/* Linear search is fine here; the map is not huge. */
static int graph_find_vertex(Graph *graph, const char *name)
{
    int i;
    for (i = 0; i < graph->vertex_count; i++) {
        if (strcmp(graph->vertices[i].name, name) == 0) {
            return i;
        }
    }
    return -1;
}

/* Returns the vertex id for a name, creating it if the config mentions it first. */
static int graph_get_or_add_vertex(Graph *graph, const char *name)
{
    int found = graph_find_vertex(graph, name);
    if (found >= 0) {
        return found;
    }
    if (!valid_name(name) || graph->vertex_count >= MAX_VERTICES) {
        return -1;
    }
    found = graph->vertex_count++;
    snprintf(graph->vertices[found].name, sizeof(graph->vertices[found].name), "%s", name);
    graph->vertices[found].kind = KIND_UNKNOWN;
    graph->vertices[found].active = 1;
    graph->vertices[found].probability = 0.0;
    graph->vertices[found].strait_index = -1;
    return found;
}

/* Turns an internal vertex number back into the name we print in logs. */
static const char *vertex_name(Graph *graph, int vertex)
{
    if (vertex < 0 || vertex >= graph->vertex_count) {
        return "?";
    }
    return graph->vertices[vertex].name;
}

/* Give a node its role. If one node is both producer and strait, something went wrong. */
static int graph_set_kind(Graph *graph, int vertex, VertexKind kind)
{
    VertexKind old;
    if (vertex < 0 || vertex >= graph->vertex_count) {
        return -1;
    }
    old = graph->vertices[vertex].kind;
    if (old != KIND_UNKNOWN && old != kind) {
        return -1;
    }
    graph->vertices[vertex].kind = kind;
    graph->vertices[vertex].active = 1;
    return 0;
}

/* Add a two-way route. The figure is drawn like an undirected map, so this felt right. */
static int graph_add_edge(Graph *graph, const char *a, const char *b, int time)
{
    int a_index = graph_get_or_add_vertex(graph, a);
    int b_index = graph_get_or_add_vertex(graph, b);
    if (a_index < 0 || b_index < 0 || time < 0) {
        return -1;
    }
    graph->edge_time[a_index][b_index] = time;
    graph->edge_time[b_index][a_index] = time;
    return 0;
}

/* Shared helper for producer, consumer, and strait config lines. */
static int graph_add_entity(Config *config, const char *name, VertexKind kind,
                              double probability, int strait_time)
{
    int vertex = graph_get_or_add_vertex(&config->graph, name);
    if (vertex < 0 || graph_set_kind(&config->graph, vertex, kind) != 0) {
        return -1;
    }
    if (kind == KIND_PRODUCER || kind == KIND_CONSUMER) {
        config->graph.vertices[vertex].probability = probability;
    } else if (kind == KIND_STRAIT) {
        config->strait_travel_time[vertex] = strait_time;
    }
    config->graph_loaded = 1;
    return 0;
}

/* mkdir is allowed to succeed if the folder is already there. */
static int mkdir_if_needed(const char *path)
{
    if (mkdir(path, 0775) == 0) {
        return 0;
    }
    if (errno == EEXIST) {
        return 0;
    }
    return -1;
}

/* Every simulation run gets its own folder so logs from old runs survive. */
static void make_run_dir(Config *config, char *buffer, size_t size)
{
    struct timeval now;
    gettimeofday(&now, NULL);
    snprintf(buffer, size, "%s/part%d/run_%ld_%06ld_%ld",
             config->logs_root, config->part,
             (long)now.tv_sec, (long)now.tv_usec, (long)getpid());
}

/* Real elapsed wall-clock time since the simulation started. */
static double elapsed_real_seconds(Sim *sim)
{
    struct timespec now;
    double secs;
    clock_gettime(CLOCK_MONOTONIC, &now);
    secs = (double)(now.tv_sec - sim->start_time.tv_sec);
    secs += (double)(now.tv_nsec - sim->start_time.tv_nsec) / 1000000000.0;
    return secs;
}

/* Simulation time is wall-clock time divided by TIME_SCALE. */
static int sim_time(Sim *sim)
{
    double scaled = elapsed_real_seconds(sim) / sim->config.time_scale;
    if (scaled < 0.0) {
        return 0;
    }
    return (int)scaled;
}

/* nanosleep wrapper that retries if a signal interrupts it. */
static void sleep_real_seconds(double seconds)
{
    struct timespec req;
    struct timespec rem;
    if (seconds <= 0.0) {
        return;
    }
    req.tv_sec = (time_t)seconds;
    req.tv_nsec = (long)((seconds - (double)req.tv_sec) * 1000000000.0);
    while (nanosleep(&req, &rem) == -1 && errno == EINTR) {
        req = rem;
    }
}

/* Sleep in simulation seconds, not raw real seconds. */
static void sleep_sim_seconds(Sim *sim, int seconds)
{
    sleep_real_seconds((double)seconds * sim->config.time_scale);
}

/* Producer/consumer loops use this so they fire once per sim second. */
static void sleep_until_sim_second(Sim *sim, int target)
{
    double target_real = (double)target * sim->config.time_scale;
    double remain = target_real - elapsed_real_seconds(sim);
    sleep_real_seconds(remain);
}

/* Random supply/demand amount in the expected range [1, Smax]. */
static int random_amount(unsigned int *seed, int smax)
{
    return (int)(rand_r(seed) % (unsigned int)smax) + 1;
}

/* Coffee quality is encoded as 1 low, 2 mid, 3 high. */
static int random_quality(unsigned int *seed)
{
    return (int)(rand_r(seed) % 3U) + 1;
}

/* Probability check for "does this producer/consumer create something this second?" */
static int probability_hit(unsigned int *seed, double probability)
{
    double draw = (double)rand_r(seed) / ((double)RAND_MAX + 1.0);
    return draw < probability;
}

/* Prepare the bounded log queue used by all worker threads. */
static void log_queue_init(LogQueue *queue)
{
    memset(queue, 0, sizeof(*queue));
    pthread_mutex_init(&queue->mutex, NULL);
    pthread_cond_init(&queue->not_empty, NULL);
    pthread_cond_init(&queue->not_full, NULL);
}

/* Tell the logger no more messages are coming, then wake it up. */
static void log_queue_close(LogQueue *queue)
{
    pthread_mutex_lock(&queue->mutex);
    queue->closed = 1;
    pthread_cond_broadcast(&queue->not_empty);
    pthread_cond_broadcast(&queue->not_full);
    pthread_mutex_unlock(&queue->mutex);
}

/* Worker threads call this instead of writing files directly. */
static void log_enqueue(Sim *sim, LogType type, const char *fmt, ...)
{
    LogQueue *queue = &sim->log_queue;
    LogEvent event;
    va_list args;
    va_list copy;
    int needed;

    memset(&event, 0, sizeof(event));
    event.type = type;

    va_start(args, fmt);
    va_copy(copy, args);
    needed = vsnprintf(NULL, 0, fmt, copy);
    va_end(copy);
    if (needed < 0) {
        va_end(args);
        return;
    }
    event.line = malloc((size_t)needed + 1U);
    if (!event.line) {
        va_end(args);
        return;
    }
    vsnprintf(event.line, (size_t)needed + 1U, fmt, args);
    va_end(args);

    /* Short critical section: just push the message into the ring buffer. */
    pthread_mutex_lock(&queue->mutex);
    while (queue->count == LOG_QUEUE_SIZE && !queue->closed) {
        pthread_cond_wait(&queue->not_full, &queue->mutex);
    }
    if (!queue->closed) {
        queue->events[queue->tail] = event;
        queue->tail = (queue->tail + 1) % LOG_QUEUE_SIZE;
        queue->count++;
        pthread_cond_signal(&queue->not_empty);
    } else {
        free(event.line);
    }
    pthread_mutex_unlock(&queue->mutex);
}

/* Logger waits here until a message appears, or until the queue is closed. */
static int log_dequeue(LogQueue *queue, LogEvent *event)
{
    pthread_mutex_lock(&queue->mutex);
    while (queue->count == 0 && !queue->closed) {
        pthread_cond_wait(&queue->not_empty, &queue->mutex);
    }
    if (queue->count == 0 && queue->closed) {
        pthread_mutex_unlock(&queue->mutex);
        return 0;
    }
    *event = queue->events[queue->head];
    queue->head = (queue->head + 1) % LOG_QUEUE_SIZE;
    queue->count--;
    pthread_cond_signal(&queue->not_full);
    pthread_mutex_unlock(&queue->mutex);
    return 1;
}

/* Built-in part maps for now. I left III/IV out for Bugra. */
static void setup_default_graph(Config *config)
{
    config_clear_graph(config);

    graph_add_entity(config, "P1", KIND_PRODUCER, 0.90, 0);
    graph_add_entity(config, "K1", KIND_STRAIT, 0.0, 3);
    graph_add_entity(config, "C2", KIND_CONSUMER, 0.90, 0);
    graph_add_edge(&config->graph, "P1", "K1", 2);
    graph_add_edge(&config->graph, "K1", "C2", 4);

    if (config->part >= 2) {
        graph_add_entity(config, "C1", KIND_CONSUMER, 0.50, 0);
        graph_add_edge(&config->graph, "P1", "C1", 8);
        graph_add_edge(&config->graph, "K1", "C1", 7);
    } if (config->part >= 3) {
        graph_add_entity(config, "P2", KIND_PRODUCER, 0.85, 0);
        graph_add_edge(&config->graph, "P2", "K1", 4);
        graph_add_edge(&config->graph, "P2", "C2", 2);
    } if (config->part >= 4) {
        graph_add_entity(config, "P3", KIND_PRODUCER, 0.75, 0);
        graph_add_entity(config, "C3", KIND_CONSUMER, 0.70, 0);
        graph_add_entity(config, "K2", KIND_STRAIT, 0.0, 5);
        graph_add_entity(config, "K3", KIND_STRAIT, 0.0, 7);

        graph_add_edge(&config->graph, "K1", "K3", 10);
        graph_add_edge(&config->graph, "P2", "K3", 7);
        graph_add_edge(&config->graph, "P2", "K2", 5);
        graph_add_edge(&config->graph, "K3", "P3", 1);
        graph_add_edge(&config->graph, "K3", "K2", 4);
        graph_add_edge(&config->graph, "K2", "C3", 3);
    }
}

/* Copy configured graph into the live sim and create one mutex/cond per strait. */
static int setup_graph(Sim *sim)
{
    int i;
    sim->graph = sim->config.graph;
    sim->strait_count = 0;
    for (i = 0; i < sim->graph.vertex_count; i++) {
        if (!sim->graph.vertices[i].active) {
            continue;
        }
        if (sim->graph.vertices[i].kind == KIND_STRAIT) {
            Strait *strait;
            if (sim->strait_count >= MAX_STRAITS) {
                fprintf(stderr, "too many straits; max is %d\n", MAX_STRAITS);
                return -1;
            }
            sim->graph.vertices[i].strait_index = sim->strait_count;
            strait = &sim->straits[sim->strait_count];
            memset(strait, 0, sizeof(*strait));
            strait->id = sim->strait_count + 1;
            strait->vertex = i;
            strait->travel_time = sim->config.strait_travel_time[i];
            pthread_mutex_init(&strait->mutex, NULL);
            pthread_cond_init(&strait->cond, NULL);
            sim->strait_count++;
        }
    }
    return 0;
}

/* If a vertex is a strait, return its runtime strait array index. */
static int strait_index_for_vertex(Graph *graph, int vertex)
{
    if (vertex < 0 || vertex >= graph->vertex_count) {
        return -1;
    }
    return graph->vertices[vertex].strait_index;
}

/* Priority rule: higher quality, then bigger amount, then earlier ticket. */
static int best_waiting_index(Strait *strait)
{
    int best = -1;
    int i;
    for (i = 0; i < strait->waiting_count; i++) {
        StraitRequest *cur = strait->waiting[i];
        StraitRequest *best_req;
        if (best < 0) {
            best = i;
            continue;
        }
        best_req = strait->waiting[best];
        if (cur->quality > best_req->quality ||
            (cur->quality == best_req->quality && cur->amount > best_req->amount) ||
            (cur->quality == best_req->quality && cur->amount == best_req->amount &&
             cur->ticket < best_req->ticket)) {
            best = i;
        }
    }
    return best;
}

/* Build a small comma-separated list for strait.log. */
static void waiting_text(Strait *strait, char *buffer, size_t size)
{
    int i;
    size_t used = 0;
    if (size == 0) {
        return;
    }
    buffer[0] = '\0';
    for (i = 0; i < strait->waiting_count; i++) {
        int written = snprintf(buffer + used, size - used, "%sF%d",
                                 used == 0 ? "" : ",",
                                 strait->waiting[i]->freight_id);
        if (written < 0 || (size_t)written >= size - used) {
            break;
        }
        used += (size_t)written;
    }
    if (used == 0) {
        snprintf(buffer, size, "none");
    }
}

/* One freight enters and passes a strait. This is where the one-at-a-time rule lives. */
static void enter_and_pass_strait(Sim *sim, int strait_index, int freight_id,
                                    int quality, int amount)
{
    Strait *strait = &sim->straits[strait_index];
    StraitRequest request;
    char waiters[256];
    int i;
 
    request.freight_id = freight_id;
    request.quality = quality;
    request.amount = amount;
 
    /* Wait under this strait's own lock; no coffee-list lock is held here. */
    pthread_mutex_lock(&strait->mutex);
    request.ticket = strait->next_ticket++;
    if (strait->reserved_count > 0) {
        strait->reserved_count--;
    }
    if (strait->waiting_count < MAX_WAITING) {
        strait->waiting[strait->waiting_count++] = &request;
    }
 
    while (strait->busy || strait->waiting[best_waiting_index(strait)] != &request) {
        pthread_cond_wait(&strait->cond, &strait->mutex);
    }
    /* This freight won the priority check, so remove it from the waiting list. */
    for (i = 0; i < strait->waiting_count; i++) {
        if (strait->waiting[i] == &request) {
            int j;
            for (j = i; j + 1 < strait->waiting_count; j++) {
                strait->waiting[j] = strait->waiting[j + 1];
            }
            strait->waiting_count--;
            break;
        }
    }
 
    strait->busy = 1;
    waiting_text(strait, waiters, sizeof(waiters));
    log_enqueue(sim, LOG_STRAIT,
                  "time=%d strait=%s freight=F%d entered waiters=%s",
                  sim_time(sim), vertex_name(&sim->graph, strait->vertex),
                  freight_id, waiters);
    pthread_mutex_unlock(&strait->mutex);
 
    sleep_sim_seconds(sim, strait->travel_time);
 
    pthread_mutex_lock(&strait->mutex);
    strait->busy = 0;
    waiting_text(strait, waiters, sizeof(waiters));
    log_enqueue(sim, LOG_STRAIT,
                  "time=%d strait=%s freight=F%d exited waiters=%s",
                  sim_time(sim), vertex_name(&sim->graph, strait->vertex),
                  freight_id, waiters);
    pthread_cond_broadcast(&strait->cond);
    pthread_mutex_unlock(&strait->mutex);
}

/* Dijkstra-ish shortest path over the active graph. Simple but does the job. */
static int shortest_path(Graph *graph, int start, int goal, int *path, int *path_count)
{
    int dist[MAX_VERTICES];
    int prev[MAX_VERTICES];
    int used[MAX_VERTICES];
    int reverse[MAX_PATH];
    int reverse_count = 0;
    int i;

    for (i = 0; i < graph->vertex_count; i++) {
        dist[i] = INT_MAX / 4;
        prev[i] = -1;
        used[i] = 0;
    }
    dist[start] = 0;

    for (;;) {
        int best = -1;
        int v;
        for (v = 0; v < graph->vertex_count; v++) {
            if (graph->vertices[v].active && !used[v] &&
                (best < 0 || dist[v] < dist[best])) {
                best = v;
            }
        }
        if (best < 0 || best == goal) {
            break;
        }
        used[best] = 1;
        for (v = 0; v < graph->vertex_count; v++) {
            int edge = graph->edge_time[best][v];
            if (graph->vertices[v].active && edge >= 0 &&
                dist[best] + edge < dist[v]) {
                dist[v] = dist[best] + edge;
                prev[v] = best;
            }
        }
    }

    if (dist[goal] >= INT_MAX / 8) {
        return 0;
    }

    for (i = goal; i >= 0 && reverse_count < MAX_PATH; i = prev[i]) {
        reverse[reverse_count++] = i;
        if (i == start) {
            break;
        }
    }
    if (reverse_count == 0 || reverse[reverse_count - 1] != start) {
        return 0;
    }
    *path_count = reverse_count;
    for (i = 0; i < reverse_count; i++) {
        path[i] = reverse[reverse_count - 1 - i];
    }
    return 1;
}

/* Format a path like P1->K1->C2 for freight.log. */
static void path_text(Graph *graph, int *path, int path_count, char *buffer, size_t size)
{
    int i;
    size_t used = 0;
    buffer[0] = '\0';
    for (i = 0; i < path_count; i++) {
        int written = snprintf(buffer + used, size - used, "%s%s",
                                 i == 0 ? "" : "->", vertex_name(graph, path[i]));
        if (written < 0 || (size_t)written >= size - used) {
            break;
        }
        used += (size_t)written;
    }
}

/* Before matching, check that the route probably finishes before Tmax. */
static int reserve_route_if_fits(Sim *sim, int producer, int consumer)
{
    int path[MAX_PATH];
    int path_count = 0;
    int estimate = 0;
    int i;

    if (!shortest_path(&sim->graph, producer, consumer, path, &path_count)) {
        return 0;
    }

    /* Add route travel plus a rough strait wait. Not perfect, but close enough for this sim. */
    for (i = 0; i + 1 < path_count; i++) {
        int from = path[i];
        int to = path[i + 1];
        int strait_index;
        estimate += sim->graph.edge_time[from][to];
        strait_index = strait_index_for_vertex(&sim->graph, to);
        if (strait_index >= 0) {
            Strait *strait = &sim->straits[strait_index];
            int pending;
            pthread_mutex_lock(&strait->mutex);
            pending = strait->waiting_count + strait->reserved_count + (strait->busy ? 1 : 0);
            estimate += strait->travel_time * (pending + 1);
            pthread_mutex_unlock(&strait->mutex);
        }
    }

    if (sim_time(sim) + estimate > sim->config.tmax) {
        return 0;
    }

    /* Reserve future strait slots, otherwise many freights can all think the same strait is free. */
    for (i = 0; i + 1 < path_count; i++) {
        int to = path[i + 1];
        int strait_index = strait_index_for_vertex(&sim->graph, to);
        if (strait_index >= 0) {
            Strait *strait = &sim->straits[strait_index];
            pthread_mutex_lock(&strait->mutex);
            strait->reserved_count++;
            pthread_mutex_unlock(&strait->mutex);
        }
    }

    return 1;
}

/* Dump current production/demand lists after changes. Verbose, but the logs become clearer. */
static void log_list_state_locked(Sim *sim, const char *reason)
{
    int i;
    char *supplies;
    char *demands;
    size_t supply_size;
    size_t demand_size;
    size_t used = 0;

    supply_size = (size_t)(sim->supply_count + 1) * 64U + 64U;
    demand_size = (size_t)(sim->demand_count + 1) * 64U + 64U;
    supplies = malloc(supply_size);
    demands = malloc(demand_size);
    if (!supplies || !demands) {
        free(supplies);
        free(demands);
        log_enqueue(sim, LOG_COFFEE,
                      "time=%d state=%s supplies=[list_snapshot_failed] demands=[list_snapshot_failed]",
                      sim_time(sim), reason);
        return;
    }

    supplies[0] = '\0';
    for (i = 0; i < sim->supply_count; i++) {
        int written = snprintf(supplies + used, supply_size - used,
                                 "%sP%d:%s:q%d:a%d",
                                 i == 0 ? "" : ",",
                                 sim->supplies[i].id,
                                 vertex_name(&sim->graph, sim->supplies[i].producer),
                                 sim->supplies[i].quality,
                                 sim->supplies[i].amount);
        if (written < 0 || (size_t)written >= supply_size - used) {
            break;
        }
        used += (size_t)written;
    }
    if (used == 0) {
        snprintf(supplies, supply_size, "empty");
    }

    used = 0;
    demands[0] = '\0';
    for (i = 0; i < sim->demand_count; i++) {
        int written = snprintf(demands + used, demand_size - used,
                                 "%sD%d:%s:q%d:a%d",
                                 i == 0 ? "" : ",",
                                 sim->demands[i].id,
                                 vertex_name(&sim->graph, sim->demands[i].consumer),
                                 sim->demands[i].quality,
                                 sim->demands[i].amount);
        if (written < 0 || (size_t)written >= demand_size - used) {
            break;
        }
        used += (size_t)written;
    }
    if (used == 0) {
        snprintf(demands, demand_size, "empty");
    }

    log_enqueue(sim, LOG_COFFEE, "time=%d state=%s supplies=[%s] demands=[%s]",
                  sim_time(sim), reason, supplies, demands);
    free(supplies);
    free(demands);
}

/* Atomically find a compatible supply-demand pair and remove both list items. */
static int take_match(Sim *sim, Match *match)
{
    int si;
    int di;
 
    /* This lock covers both lists. Otherwise two freights could grab the same coffee. */
    pthread_mutex_lock(&sim->list_mutex);
    for (si = 0; si < sim->supply_count; si++) {
        for (di = 0; di < sim->demand_count; di++) {
            SupplyItem supply = sim->supplies[si];
            DemandItem demand = sim->demands[di];
            if (supply.quality >= demand.quality && supply.amount >= demand.amount) {
                int i;
                if (!reserve_route_if_fits(sim, supply.producer, demand.consumer)) {
                    continue;
                }
                match->freight_id = sim->next_freight_id++;
                match->producer = supply.producer;
                match->consumer = demand.consumer;
                match->production_id = supply.id;
                match->demand_id = demand.id;
                match->quality = supply.quality;
                match->amount  = supply.amount;
 
                for (i = si; i + 1 < sim->supply_count; i++) {
                    sim->supplies[i] = sim->supplies[i + 1];
                }
                sim->supply_count--;
                for (i = di; i + 1 < sim->demand_count; i++) {
                    sim->demands[i] = sim->demands[i + 1];
                }
                sim->demand_count--;
 
                log_enqueue(sim, LOG_COFFEE,
                              "time=%d freight=F%d removed production=P%d producer=%s demand=D%d consumer=%s q=%d amount=%d",
                              sim_time(sim), match->freight_id, supply.id,
                              vertex_name(&sim->graph, supply.producer), demand.id,
                              vertex_name(&sim->graph, demand.consumer),
                              match->quality, match->amount);
                log_list_state_locked(sim, "after_match");
                pthread_mutex_unlock(&sim->list_mutex);
                return 1;
            }
        }
    }
    pthread_mutex_unlock(&sim->list_mutex);
    return 0;
}

/* Producer thread: once per sim second, maybe create a supply item. */
static void *producer_thread(void *arg)
{
    EntityArg *entity = (EntityArg *)arg;
    Sim *sim = entity->sim;
    int second;

    for (second = 0; second <= sim->config.tmax; second++) {
        sleep_until_sim_second(sim, second);
        if (sim_time(sim) > sim->config.tmax) {
            break;
        }
        if (probability_hit(&entity->seed, entity->probability)) {
            SupplyItem item;
            pthread_mutex_lock(&sim->list_mutex);
            if (sim->supply_count < MAX_ITEMS) {
                item.id = sim->next_supply_id++;
                item.producer = entity->vertex;
                item.quality = random_quality(&entity->seed);
                item.amount = random_amount(&entity->seed, sim->config.smax);
                item.time = sim_time(sim);
                sim->supplies[sim->supply_count++] = item;
                log_enqueue(sim, LOG_COFFEE,
                              "time=%d added production=P%d producer=%s q=%d amount=%d",
                              item.time, item.id,
                              vertex_name(&sim->graph, item.producer),
                              item.quality, item.amount);
                log_list_state_locked(sim, "after_supply_add");
            }
            pthread_mutex_unlock(&sim->list_mutex);
        }
    }
    return NULL;
}

/* Consumer thread: once per sim second, maybe create a demand item. */
static void *consumer_thread(void *arg)
{
    EntityArg *entity = (EntityArg *)arg;
    Sim *sim = entity->sim;
    int second;

    for (second = 0; second <= sim->config.tmax; second++) {
        sleep_until_sim_second(sim, second);
        if (sim_time(sim) > sim->config.tmax) {
            break;
        }
        if (probability_hit(&entity->seed, entity->probability)) {
            DemandItem item;
            pthread_mutex_lock(&sim->list_mutex);
            if (sim->demand_count < MAX_ITEMS) {
                item.id = sim->next_demand_id++;
                item.consumer = entity->vertex;
                item.quality = random_quality(&entity->seed);
                item.amount = random_amount(&entity->seed, sim->config.smax);
                item.time = sim_time(sim);
                sim->demands[sim->demand_count++] = item;
                log_enqueue(sim, LOG_COFFEE,
                              "time=%d added demand=D%d consumer=%s q=%d amount=%d",
                              item.time, item.id,
                              vertex_name(&sim->graph, item.consumer),
                              item.quality, item.amount);
                log_list_state_locked(sim, "after_demand_add");
            }
            pthread_mutex_unlock(&sim->list_mutex);
        }
    }
    return NULL;
}

/* Move one matched order from producer to consumer over the shortest route. */
static void travel_match(Sim *sim, Match *match)
{
    int path[MAX_PATH];
    int path_count = 0;
    int i;
    char route[1024];

    if (!shortest_path(&sim->graph, match->producer, match->consumer,
                         path, &path_count)) {
        log_enqueue(sim, LOG_FREIGHT,
                      "time=%d freight=F%d no_route from=%s to=%s production=P%d demand=D%d",
                      sim_time(sim), match->freight_id,
                      vertex_name(&sim->graph, match->producer),
                      vertex_name(&sim->graph, match->consumer),
                      match->production_id, match->demand_id);
        return;
    }

    path_text(&sim->graph, path, path_count, route, sizeof(route));
    match->departure_time = sim_time(sim);
    log_enqueue(sim, LOG_FREIGHT,
                  "time=%d freight=F%d depart from=%s to=%s production=P%d demand=D%d q=%d amount=%d route=%s",
                  match->departure_time, match->freight_id,
                  vertex_name(&sim->graph, match->producer),
                  vertex_name(&sim->graph, match->consumer),
                  match->production_id, match->demand_id, match->quality,
                  match->amount, route);

    for (i = 0; i + 1 < path_count; i++) {
        int from = path[i];
        int to = path[i + 1];
        int edge_time = sim->graph.edge_time[from][to];
        int strait_index;
        sleep_sim_seconds(sim, edge_time);
        /* If the next vertex is a strait, edge travel gets us there, then strait crossing happens. */
        strait_index = strait_index_for_vertex(&sim->graph, to);
        if (strait_index >= 0) {
            enter_and_pass_strait(sim, strait_index, match->freight_id,
                                    match->quality, match->amount);
        }
    }

    log_enqueue(sim, LOG_FREIGHT,
                  "time=%d freight=F%d arrived from=%s at=%s production=P%d demand=D%d q=%d amount=%d departed=%d arrived=%d",
                  sim_time(sim), match->freight_id,
                  vertex_name(&sim->graph, match->producer),
                  vertex_name(&sim->graph, match->consumer),
                  match->production_id, match->demand_id, match->quality,
                  match->amount, match->departure_time, sim_time(sim));
}

/* Freight worker: keep looking for matches until simulation time is over. */
static void *freight_thread(void *arg)
{
    FreightArg *freight = (FreightArg *)arg;
    Sim *sim = freight->sim;

    while (sim_time(sim) <= sim->config.tmax) {
        Match match;

        pthread_mutex_lock(&sim->active_mutex);
        while (sim->active_freights >= sim->config.freight_count &&
               sim_time(sim) <= sim->config.tmax) {
            pthread_cond_wait(&sim->active_cond, &sim->active_mutex);
        }
        if (sim_time(sim) > sim->config.tmax) {
            pthread_mutex_unlock(&sim->active_mutex);
            break;
        }
        sim->active_freights++;
        pthread_mutex_unlock(&sim->active_mutex);

        if (take_match(sim, &match)) {
            travel_match(sim, &match);
        } else {
            sleep_real_seconds(0.10 * sim->config.time_scale);
        }

        pthread_mutex_lock(&sim->active_mutex);
        sim->active_freights--;
        pthread_cond_signal(&sim->active_cond);
        pthread_mutex_unlock(&sim->active_mutex);
    }
    return NULL;
}

/* Single file-writing thread. Keeps fprintf away from the timing-sensitive workers. */
static void *logger_thread(void *arg)
{
    LoggerArg *logger = (LoggerArg *)arg;
    Sim *sim = logger->sim;
    char freight_path[640];
    char strait_path[640];
    char coffee_path[640];
    FILE *freight_file;
    FILE *strait_file;
    FILE *coffee_file;
    LogEvent event;

    snprintf(freight_path, sizeof(freight_path), "%s/freight.log", logger->part_dir);
    snprintf(strait_path, sizeof(strait_path), "%s/strait.log", logger->part_dir);
    snprintf(coffee_path, sizeof(coffee_path), "%s/coffee.log", logger->part_dir);

    freight_file = fopen(freight_path, "w");
    strait_file = fopen(strait_path, "w");
    coffee_file = fopen(coffee_path, "w");
    if (!freight_file || !strait_file || !coffee_file) {
        fprintf(stderr, "could not open log files in %s\n", logger->part_dir);
        exit(1);
    }

    while (log_dequeue(&sim->log_queue, &event)) {
        FILE *target = coffee_file;
        if (event.type == LOG_FREIGHT) {
            target = freight_file;
        } else if (event.type == LOG_STRAIT) {
            target = strait_file;
        }
        fprintf(target, "%s\n", event.line);
        fflush(target);
        free(event.line);
    }

    fclose(freight_file);
    fclose(strait_file);
    fclose(coffee_file);
    return NULL;
}

/* Baseline values; graph itself is filled later. */
static void config_default(Config *config)
{
    int i;
    memset(config, 0, sizeof(*config));
    config->part = 1;
    config->tmax = 60;
    config->smax = 5;
    config->freight_count = 6;
    config->seed = 304;
    config->time_scale = 1.0;
    snprintf(config->logs_root, sizeof(config->logs_root), "logs");
    graph_clear(&config->graph);
    for (i = 0; i < MAX_VERTICES; i++) {
        config->strait_travel_time[i] = 0;
    }
}

/* Trim whitespace around config lines. Small helper, saves annoying parsing bugs. */
static char *trim(char *text)
{
    char *end;
    while (isspace((unsigned char)*text)) {
        text++;
    }
    if (*text == '\0') {
        return text;
    }
    end = text + strlen(text) - 1;
    while (end > text && isspace((unsigned char)*end)) {
        *end = '\0';
        end--;
    }
    return text;
}

/* Parse scenario file. This is the part that lets custom names work. */
static int config_load_file(Config *config, const char *path)
{
    FILE *file;
    char line[512];
    int line_no = 0;

    file = fopen(path, "r");
    if (!file) {
        fprintf(stderr, "could not open config file: %s\n", path);
        return -1;
    }

    graph_clear(&config->graph);
    config->graph_loaded = 1;
    snprintf(config->config_path, sizeof(config->config_path), "%s", path);
    while (fgets(line, sizeof(line), file)) {
        char *tokens[16];
        char *text;
        char *comment;
        int count = 0;
        char *token;

        line_no++;
        comment = strchr(line, '#');
        if (comment) {
            *comment = '\0';
        }
        text = trim(line);
        if (*text == '\0') {
            continue;
        }

        /* strtok is enough here because config syntax is intentionally plain. */
        token = strtok(text, " \t\r\n");
        while (token && count < 16) {
            tokens[count++] = token;
            token = strtok(NULL, " \t\r\n");
        }

        if (strcmp(tokens[0], "part") == 0 && count == 2) {
            config->part = atoi(tokens[1]);
        } else if (strcmp(tokens[0], "tmax") == 0 && count == 2) {
            config->tmax = atoi(tokens[1]);
        } else if (strcmp(tokens[0], "smax") == 0 && count == 2) {
            config->smax = atoi(tokens[1]);
        } else if (strcmp(tokens[0], "freights") == 0 && count == 2) {
            config->freight_count = atoi(tokens[1]);
        } else if (strcmp(tokens[0], "seed") == 0 && count == 2) {
            config->seed = (unsigned int)strtoul(tokens[1], NULL, 10);
        } else if (strcmp(tokens[0], "time_scale") == 0 && count == 2) {
            config->time_scale = atof(tokens[1]);
        } else if (strcmp(tokens[0], "logs") == 0 && count == 2) {
            snprintf(config->logs_root, sizeof(config->logs_root), "%s", tokens[1]);
        } else if (strcmp(tokens[0], "clear_graph") == 0 && count == 1) {
            config_clear_graph(config);
        } else if (strcmp(tokens[0], "active") == 0 && count >= 2) {
            int i;
            for (i = 1; i < count; i++) {
                if (graph_get_or_add_vertex(&config->graph, tokens[i]) < 0) {
                    fprintf(stderr, "invalid vertex '%s' on config line %d\n", tokens[i], line_no);
                    fclose(file);
                    return -1;
                }
            }
        } else if (strcmp(tokens[0], "edge") == 0 && count == 4) {
            int time = atoi(tokens[3]);
            if (graph_add_edge(&config->graph, tokens[1], tokens[2], time) != 0) {
                fprintf(stderr, "invalid edge on config line %d\n", line_no);
                fclose(file);
                return -1;
            }
        } else if (strcmp(tokens[0], "producer") == 0 && count == 3) {
            if (graph_add_entity(config, tokens[1], KIND_PRODUCER, atof(tokens[2]), 0) != 0) {
                fprintf(stderr, "invalid producer on config line %d\n", line_no);
                fclose(file);
                return -1;
            }
        } else if (strcmp(tokens[0], "consumer") == 0 && count == 3) {
            if (graph_add_entity(config, tokens[1], KIND_CONSUMER, atof(tokens[2]), 0) != 0) {
                fprintf(stderr, "invalid consumer on config line %d\n", line_no);
                fclose(file);
                return -1;
            }
        } else if (strcmp(tokens[0], "strait") == 0 && count == 3) {
            if (graph_add_entity(config, tokens[1], KIND_STRAIT, 0.0, atoi(tokens[2])) != 0) {
                fprintf(stderr, "invalid strait on config line %d\n", line_no);
                fclose(file);
                return -1;
            }
        } else {
            fprintf(stderr, "invalid config line %d: %s\n", line_no, tokens[0]);
            fclose(file);
            return -1;
        }
    }

    fclose(file);
    return 0;
}

/* Catch bad scenarios before threads start and error messages get messy. */
static int validate_config(Config *config)
{
    int producer_count = 0;
    int consumer_count = 0;
    int i;

    if (!config->graph_loaded) {
        setup_default_graph(config);
    }

    for (i = 0; i < config->graph.vertex_count; i++) {
        Vertex *vertex = &config->graph.vertices[i];
        if (!vertex->active) {
            continue;
        }
        if (vertex->kind == KIND_PRODUCER) {
            producer_count++;
        } else if (vertex->kind == KIND_CONSUMER) {
            consumer_count++;
        } else if (vertex->kind == KIND_STRAIT) {
            if (config->strait_travel_time[i] <= 0) {
                fprintf(stderr, "strait %s needs positive travel time\n", vertex->name);
                return -1;
            }
        } else {
            fprintf(stderr, "active vertex %s has no role; use producer, consumer, or strait\n",
                    vertex->name);
            return -1;
        }
    }
    if (producer_count == 0 || consumer_count == 0) {
        fprintf(stderr, "scenario needs at least one producer and one consumer\n");
        return -1;
    }
    return 0;
}

/* Printed for bad CLI args or --help. */
static void usage(const char *program)
{
    fprintf(stderr,
            "usage: %s [--config FILE] [--part N|--partI|--partII|--partIII|--partIV] [--tmax N] [--smax N] [--freights N] [--seed N] [--time-scale X] [--logs DIR]\n",
            program);
}

/* Second CLI pass. Config is loaded first, then command-line overrides win. */
static int parse_args(Config *config, int argc, char **argv)
{
    int i = 1;
    while (i < argc) {
        if (strcmp(argv[i], "--part") == 0 && i + 1 < argc) {
            config->part = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--partI") == 0 || strcmp(argv[i], "--part1") == 0) {
            config->part = 1;
        } else if (strcmp(argv[i], "--partII") == 0 || strcmp(argv[i], "--part2") == 0) {
            config->part = 2;
        } else if (strcmp(argv[i], "--partIII") == 0 || strcmp(argv[i], "--part3") == 0) {
            config->part = 3;
        } else if (strcmp(argv[i], "--partIV") == 0 || strcmp(argv[i], "--part4") == 0) {
            config->part = 4;
        } else if (strcmp(argv[i], "--tmax") == 0 && i + 1 < argc) {
            config->tmax = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--smax") == 0 && i + 1 < argc) {
            config->smax = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--freights") == 0 && i + 1 < argc) {
            config->freight_count = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--seed") == 0 && i + 1 < argc) {
            config->seed = (unsigned int)strtoul(argv[++i], NULL, 10);
        } else if (strcmp(argv[i], "--time-scale") == 0 && i + 1 < argc) {
            config->time_scale = atof(argv[++i]);
        } else if (strcmp(argv[i], "--logs") == 0 && i + 1 < argc) {
            snprintf(config->logs_root, sizeof(config->logs_root), "%s", argv[++i]);
        } else if (strcmp(argv[i], "--config") == 0 && i + 1 < argc) {
            i++;
        } else if (strcmp(argv[i], "--help") == 0) {
            return 0;
        } else {
            return -1;
        }
        i++;
    }

    if (config->part < 1 || config->tmax < 0 ||
        config->smax < 1 || config->freight_count < 1 || config->time_scale <= 0.0) {
        return -1;
    }
    if (validate_config(config) != 0) {
        return -1;
    }
    return 1;
}

/* Initialize mutexes, ids, logger queue, and the runtime graph copy. */
static int sim_init(Sim *sim, Config *config)
{
    memset(sim, 0, sizeof(*sim));
    sim->config = *config;
    sim->next_supply_id = 1;
    sim->next_demand_id = 1;
    sim->next_freight_id = 1;
    pthread_mutex_init(&sim->list_mutex, NULL);
    sim->active_freights = 0;
    pthread_mutex_init(&sim->active_mutex, NULL);
    pthread_cond_init(&sim->active_cond, NULL);
    log_queue_init(&sim->log_queue);
    return setup_graph(sim);
}

/* Base directory for this part's logs, before adding run timestamp. */
static void part_dir(Config *config, char *buffer, size_t size)
{
    snprintf(buffer, size, "%s/part%d", config->logs_root, config->part);
}

/* Start all simulation threads, wait for them, then close the logger cleanly. */
static int run_simulation(Config *config)
{
    Sim sim;
    pthread_t logger_thread_id;
    pthread_t *producer_threads;
    pthread_t *consumer_threads;
    pthread_t *freight_threads;
    EntityArg *producer_args;
    EntityArg *consumer_args;
    FreightArg *freight_args;
    LoggerArg logger_arg;
    char part_base_dir[512];
    char part_dir_buffer[512];
    int producer_count = 0;
    int consumer_count = 0;
    int i;

    if (sim_init(&sim, config) != 0) {
        return 1;
    }
    part_dir(config, part_base_dir, sizeof(part_base_dir));
    make_run_dir(config, part_dir_buffer, sizeof(part_dir_buffer));
    snprintf(config->run_dir, sizeof(config->run_dir), "%s", part_dir_buffer);
    if (mkdir_if_needed(config->logs_root) != 0 ||
        mkdir_if_needed(part_base_dir) != 0 ||
        mkdir_if_needed(part_dir_buffer) != 0) {
        fprintf(stderr, "could not create log directory: %s\n", part_dir_buffer);
        return 1;
    }
    printf("logs=%s\n", part_dir_buffer);

    producer_threads = calloc((size_t)sim.graph.vertex_count, sizeof(*producer_threads));
    consumer_threads = calloc((size_t)sim.graph.vertex_count, sizeof(*consumer_threads));
    producer_args = calloc((size_t)sim.graph.vertex_count, sizeof(*producer_args));
    consumer_args = calloc((size_t)sim.graph.vertex_count, sizeof(*consumer_args));
    freight_threads = calloc((size_t)config->freight_count, sizeof(*freight_threads));
    freight_args = calloc((size_t)config->freight_count, sizeof(*freight_args));
    if (!producer_threads || !consumer_threads || !producer_args || !consumer_args ||
        !freight_threads || !freight_args) {
        fprintf(stderr, "could not allocate threads\n");
        free(producer_threads);
        free(consumer_threads);
        free(producer_args);
        free(consumer_args);
        free(freight_threads);
        free(freight_args);
        return 1;
    }

    logger_arg.sim = &sim;
    snprintf(logger_arg.part_dir, sizeof(logger_arg.part_dir), "%s", part_dir_buffer);
    pthread_create(&logger_thread_id, NULL, logger_thread, &logger_arg);

    clock_gettime(CLOCK_MONOTONIC, &sim.start_time);

    /* Create one producer/consumer thread per active producer/consumer vertex. */
    for (i = 0; i < sim.graph.vertex_count; i++) {
        Vertex *vertex = &sim.graph.vertices[i];
        if (!vertex->active) {
            continue;
        }
        if (vertex->kind == KIND_PRODUCER) {
            EntityArg *arg = &producer_args[producer_count];
            arg->sim = &sim;
            arg->vertex = i;
            arg->probability = vertex->probability;
            arg->seed = config->seed + (unsigned int)(17 * (i + 1));
            pthread_create(&producer_threads[producer_count], NULL, producer_thread, arg);
            producer_count++;
        } else if (vertex->kind == KIND_CONSUMER) {
            EntityArg *arg = &consumer_args[consumer_count];
            arg->sim = &sim;
            arg->vertex = i;
            arg->probability = vertex->probability;
            arg->seed = config->seed + (unsigned int)(31 * (i + 1));
            pthread_create(&consumer_threads[consumer_count], NULL, consumer_thread, arg);
            consumer_count++;
        }
    }

    /* F active freight workers. Basically, keep this many freights alive. */
    for (i = 0; i < config->freight_count; i++) {
        freight_args[i].sim = &sim;
        freight_args[i].slot = i + 1;
        freight_args[i].seed = config->seed + (unsigned int)(101 * (i + 1));
        pthread_create(&freight_threads[i], NULL, freight_thread, &freight_args[i]);
    }

    for (i = 0; i < producer_count; i++) {
        pthread_join(producer_threads[i], NULL);
    }
    for (i = 0; i < consumer_count; i++) {
        pthread_join(consumer_threads[i], NULL);
    }
    for (i = 0; i < config->freight_count; i++) {
        pthread_join(freight_threads[i], NULL);
    }

    log_queue_close(&sim.log_queue);
    pthread_join(logger_thread_id, NULL);

    free(producer_threads);
    free(consumer_threads);
    free(producer_args);
    free(consumer_args);
    free(freight_threads);
    free(freight_args);
    return 0;
}

/* Load config first if present, then parse overrides, then run. */
int main(int argc, char **argv)
{
    Config config;
    int parse;
    int i;

    config_default(&config);
    for (i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--config") == 0 && i + 1 < argc) {
            if (config_load_file(&config, argv[i + 1]) != 0) {
                return 1;
            }
            i++;
        }
    }
    parse = parse_args(&config, argc, argv);
    if (parse <= 0) {
        usage(argv[0]);
        return parse == 0 ? 0 : 1;
    }

    return run_simulation(&config);
}
